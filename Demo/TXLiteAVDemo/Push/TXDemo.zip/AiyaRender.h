//
//  AiyaRender.h
//  TXLiteAVDemoSmart
//
//  Created by 汪洋 on 2017/10/13.
//  Copyright © 2017年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <OpenGLES/gltypes.h>
#import <CoreGraphics/CoreGraphics.h>

@interface AiyaRender : NSObject

- (GLuint)renderToTextureWithSize:(CGSize)fboSize sourceTexture:(GLuint)sourceTexture;

- (void)destroyFramebuffer;

@end
