//
//  AiyaRender.m
//  TXLiteAVDemoSmart
//
//  Created by 汪洋 on 2017/10/13.
//  Copyright © 2017年 Tencent. All rights reserved.
//

#import "AiyaRender.h"
#import <OpenGLES/EAGL.h>
#import <OpenGLES/gltypes.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>
#import <AVFoundation/AVFoundation.h>
#import <AiyaCameraSDK/AiyaCameraSDK.h>

static const NSString * kVertexShaderString =
@"attribute vec4 position;\n"
"attribute vec2 inputTextureCoordinate;\n"
"varying mediump vec2 v_texCoord;\n"
"void main()\n"
"{\n"
"    gl_Position = position;\n"
"    v_texCoord = inputTextureCoordinate;\n"
"}\n";

static const NSString *kInputFragmentShaderString =
@"precision lowp float;\n"
"uniform sampler2D mTexture;\n"
"varying highp vec2 v_texCoord;\n"
"void main()\n"
"{\n"
"    gl_FragColor = texture2D(mTexture, v_texCoord);\n"
"}\n";

@interface AiyaRender() {
    CVOpenGLESTextureCacheRef coreVideoTextureCache;
    
    GLuint inputProgram;
    GLint inputPositionAttribute, inputTextureCoordinateAttribute;
    GLint inputInputTextureUniform;
    GLuint inputFramebuffer, inputFrameTexture;
    CVPixelBufferRef inputCVPixelBuffer;
    CVOpenGLESTextureRef inputTextureRef;
    
    GLuint outputTexture;
    
    AiyaEffectHandler *effectHandler;
}

@end

@implementation AiyaRender

- (instancetype)init
{
    self = [super init];
    if (self) {
        [AiyaLicenseManager initLicense:@"b9f205f128fd4bc58f4554d57a6b0847" succ:^{
            NSLog(@"license success");
        } failed:^(NSString *errMsg) {
            NSLog(@"license failed");
        }];
    }
    return self;
}

- (GLuint)renderToTextureWithSize:(CGSize)fboSize sourceTexture:(GLuint)sourceTexture{
    
    if (!inputProgram) {
        [self createInputProgram];
    }
    
    if (!inputFramebuffer) {
        [self createInputFramebufferWithWidth:fboSize.width height:fboSize.height];
    }
    
    glBindFramebuffer(GL_FRAMEBUFFER, inputFramebuffer);
    glViewport(0, 0, fboSize.width, fboSize.height);
    
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glUseProgram(inputProgram);
    
    glActiveTexture(GL_TEXTURE4);
    glBindTexture(GL_TEXTURE_2D, sourceTexture);
    glUniform1i(inputInputTextureUniform, 4);
    
    static const GLfloat squareVertices[] = {
        -1.0f, -1.0f,
        1.0f, -1.0f,
        -1.0f,  1.0f,
        1.0f,  1.0f,
    };
    
    static const GLfloat textureCoordinates[] = {
        0.0f, 0.0f,
        1.0f, 0.0f,
        0.0f, 1.0f,
        1.0f, 1.0f,
    };
    
    glEnableVertexAttribArray(inputPositionAttribute);
    glEnableVertexAttribArray(inputTextureCoordinateAttribute);
    glVertexAttribPointer(inputPositionAttribute, 2, GL_FLOAT, 0, 0, squareVertices);
    glVertexAttribPointer(inputTextureCoordinateAttribute, 2, GL_FLOAT, 0, 0, textureCoordinates);
    
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    
    if (!outputTexture) {
        [self createOutputTextureWithWidth:fboSize.width height:fboSize.height];
    }
    
    glBindTexture(GL_TEXTURE_2D, outputTexture);
    
    glFinish();
    
    EAGLContext *context = [self context];

    if (!effectHandler) {
        effectHandler = [[AiyaEffectHandler alloc]init];
        effectHandler.bigEyesScale = 1;
        effectHandler.slimFaceScale = 1;
        effectHandler.effectPath = [[NSBundle mainBundle] pathForResource:@"meta" ofType:@"json" inDirectory:@"gougou"];
    }

    AIYA_CAMERA_EFFECT_ERROR_CODE error;
    [effectHandler processWithPixelBuffer:inputCVPixelBuffer error:&error];

    if (error) {
        NSLog(@"aiyaEffectHandler Error %lu",error);
    }
    
    [EAGLContext setCurrentContext:context];
    
    CVPixelBufferLockBaseAddress(inputCVPixelBuffer, 0);

    int bufferHeight = (int) CVPixelBufferGetHeight(inputCVPixelBuffer);
    int bytesPerRow = (int) CVPixelBufferGetBytesPerRow(inputCVPixelBuffer);
    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, bytesPerRow / 4, bufferHeight, 0, GL_BGRA, GL_UNSIGNED_BYTE, CVPixelBufferGetBaseAddress(inputCVPixelBuffer));
    
    CVPixelBufferUnlockBaseAddress(inputCVPixelBuffer, 0);

    return outputTexture;
}

- (void)destroyFramebuffer{
    [self destroyOutputTexture];
    [self destroyInputFramebuffer];
}

- (void)createInputProgram{
    inputProgram = [self createProgramWithVert:kVertexShaderString frag:kInputFragmentShaderString];
    inputPositionAttribute = glGetAttribLocation(inputProgram, [@"position" UTF8String]);
    inputTextureCoordinateAttribute = glGetAttribLocation(inputProgram, [@"inputTextureCoordinate" UTF8String]);
    inputInputTextureUniform = glGetUniformLocation(inputProgram, [@"mTexture" UTF8String]);
}

#pragma mark - 用于导数据的Framebuffer
- (void)createInputFramebufferWithWidth:(GLsizei)width height:(GLsizei)height{
    
    glGenFramebuffers(1, &inputFramebuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, inputFramebuffer);
    
    // 为了导出纹理数据 创建CVPixelBuffer
    CFDictionaryRef empty = CFDictionaryCreate(kCFAllocatorDefault, NULL, NULL, 0, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    CFMutableDictionaryRef attrs = CFDictionaryCreateMutable(kCFAllocatorDefault, 1, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    CFDictionarySetValue(attrs, kCVPixelBufferIOSurfacePropertiesKey, empty);
    
    CVPixelBufferCreate(kCFAllocatorDefault, (int)width, (int)height, kCVPixelFormatType_32BGRA, attrs, &inputCVPixelBuffer);
    
    CVOpenGLESTextureCacheCreateTextureFromImage (kCFAllocatorDefault, self.coreVideoTextureCache, inputCVPixelBuffer,NULL, GL_TEXTURE_2D, GL_RGBA, (int)width, (int)height, GL_BGRA, GL_UNSIGNED_BYTE, 0, &inputTextureRef);
    
    CFRelease(attrs);
    CFRelease(empty);
    
    inputFrameTexture = CVOpenGLESTextureGetName(inputTextureRef);
    glBindTexture(CVOpenGLESTextureGetTarget(inputTextureRef), inputFrameTexture);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, inputFrameTexture, 0);
    glBindTexture(GL_TEXTURE_2D, 0);
}

- (void)destroyInputFramebuffer{
    
    if (inputFramebuffer){
        glDeleteFramebuffers(1, &inputFramebuffer);
        inputFramebuffer = 0;
    }
    
    if (inputCVPixelBuffer)
    {
        CFRelease(inputCVPixelBuffer);
        inputCVPixelBuffer = NULL;
    }
    
    if (inputTextureRef)
    {
        CFRelease(inputTextureRef);
        inputTextureRef = NULL;
    }
    
    if (inputFrameTexture) {
        glDeleteTextures(1, &inputFrameTexture);
        inputFrameTexture = 0;
    }
}

- (void)createOutputTextureWithWidth:(GLsizei)width height:(GLsizei)height{

    glActiveTexture(GL_TEXTURE1);
    glGenTextures(1, &outputTexture);
    glBindTexture(GL_TEXTURE_2D, outputTexture);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
    glTexImage2D(GL_TEXTURE_2D, 0,GL_RGBA, width, height, 0, GL_BGRA, GL_UNSIGNED_BYTE, 0);
    glBindTexture(GL_TEXTURE_2D, 0);
}

- (void)destroyOutputTexture{
    if (outputTexture) {
        glDeleteTextures(1, &outputTexture);
        outputTexture = 0;
    }
}

#pragma mark util
- (EAGLContext *)context {
    return [EAGLContext currentContext];
}

- (CVOpenGLESTextureCacheRef)coreVideoTextureCache {
    if (coreVideoTextureCache == NULL){
        EAGLContext* context = [self context];
        CVReturn err = CVOpenGLESTextureCacheCreate(kCFAllocatorDefault, NULL, context, NULL, &coreVideoTextureCache);
        
        if (err){
            NSAssert(NO, @"Error at CVOpenGLESTextureCacheCreate %d", err);
        }
    }
    
    return coreVideoTextureCache;
}

- (BOOL)compileShader:(GLuint *)shader type:(GLenum)type string:(const NSString *)shaderString{
    
    GLint status;
    const GLchar *source;
    
    source = (GLchar *)[shaderString UTF8String];
    if (!source){
        NSLog(@"Failed to load vertex shader");
        return NO;
    }
    
    *shader = glCreateShader(type);
    glShaderSource(*shader, 1, &source, NULL);
    glCompileShader(*shader);
    
    glGetShaderiv(*shader, GL_COMPILE_STATUS, &status);
    
    if (status != GL_TRUE) {
        GLint logLength;
        glGetShaderiv(*shader, GL_INFO_LOG_LENGTH, &logLength);
        if (logLength > 0){
            GLchar *log = (GLchar *)malloc(logLength);
            glGetShaderInfoLog(*shader, logLength, &logLength, log);
            NSLog(@"Failed to compile shader %s", log);
            free(log);
        }
    }
    
    return status == GL_TRUE;
}

- (GLuint)createProgramWithVert:(const NSString *)vShaderString frag:(const NSString *)fShaderString{
    
    GLuint program = glCreateProgram();
    GLuint vertShader, fragShader;
    if (![self compileShader:&vertShader
                        type:GL_VERTEX_SHADER
                      string:vShaderString]){
        NSLog(@"Failed to compile vertex shader");
    }
    
    if (![self compileShader:&fragShader
                        type:GL_FRAGMENT_SHADER
                      string:fShaderString]){
        NSLog(@"Failed to compile fragment shader");
    }
    
    glAttachShader(program, vertShader);
    glAttachShader(program, fragShader);
    
    
    GLint status;
    
    glLinkProgram(program);
    
    glGetProgramiv(program, GL_LINK_STATUS, &status);
    if (status == GL_FALSE)
        NSLog(@"Failed to link shader");
    
    if (vertShader)
    {
        glDeleteShader(vertShader);
        vertShader = 0;
    }
    if (fragShader)
    {
        glDeleteShader(fragShader);
        fragShader = 0;
    }
    
    return program;
}

@end
